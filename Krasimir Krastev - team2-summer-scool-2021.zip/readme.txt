This archive contains delived solution for Crypto AI Trader, prepared by Team 2 for "Summer school on modelling & complex systems"
It contains the proposed model for first part of the task, and some of the functionality required in second part of the assigment.

Date: 07/11/2021

Team members:
Ivanina Mancheva
Krasimir Krastev
Galina Nencheva